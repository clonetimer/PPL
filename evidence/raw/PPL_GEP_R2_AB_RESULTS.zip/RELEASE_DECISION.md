# PPL GEP R2 Stable Promotion Review

Generated: 2026-08-25T13:00:24.632Z

## Decision

| Component | Decision |
|---|---|
| Experience Control Overlay 0.1.0-rc.1 | **HOLD** |
| Host 0.1.13-rc.1 | **HOLD** |
| Life Binding 0.1.2-rc.1 | **HOLD_NOT_ELIGIBLE_ON_RESEARCH_EVIDENCE** |

## Real A/B gates

| Gate | Result | Value |
|---|---|---:|
| candidateAttestation | PASS | judge=true |
| historicalPayload | PASS | 4 |
| minimumPairs | PASS | 48 |
| treatmentPassRate | FAIL | 0 |
| pairedImprovementDirection | FAIL | 0>0 |
| pairedSignificance | FAIL | 1 |
| severeFindings | FAIL | 43 |
| internalLeakage | FAIL | 14 |
| treatmentMessageNotEcho | FAIL | 0.8541666666666666 |
| humanVisibleText | FAIL | incomplete-or-unattributed |

## Metrics

```json
{
  "completePairs": 48,
  "distinctPromotionEligibleHistoricalCases": 4,
  "controlFirstPassPassRate": 0,
  "treatmentFirstPassPassRate": 0,
  "controlFailTreatmentPass": 0,
  "controlPassTreatmentFail": 0,
  "discordantPairs": 0,
  "mcnemarExactTwoSidedP": 1,
  "treatmentSevereFindings": 43,
  "treatmentInternalLeakage": 14,
  "controlMessageNotEchoRate": 0.75,
  "treatmentMessageNotEchoRate": 0.8541666666666666,
  "controlExactOpposingEvidenceVisibleRate": 0,
  "treatmentExactOpposingEvidenceVisibleRate": 0.041666666666666664,
  "controlMedianLatencyMs": 2378.074650000024,
  "treatmentMedianLatencyMs": 2602.4001999999746,
  "controlP95LatencyMs": 4479.030625000001,
  "treatmentP95LatencyMs": 7637.391954999999,
  "controlMedianTotalTokens": 3386.5,
  "treatmentMedianTotalTokens": 3886.5,
  "humanReviewComplete": false,
  "humanReviewPass": false
}
```

## Interpretation

- Research A/B evidence can qualify the Overlay and Research Host integration only.
- Host Stable still requires a complete no-Overlay Application soak on Host 0.1.13-rc.1; this R2 targeted experiment does not silently substitute for that soak.
- Research evidence cannot promote Life Binding 0.1.2-rc.1. A separate Life-domain real trial is mandatory.
- Synthetic fixtures, incomplete historical payloads, missing human review, or an unqualified Judge always force HOLD.
