# PPL 0.1.0 Stable — Clean DeepSeek Harness deployment

Reference host: DeepSeek Harness `0.1.0-rc.7`, commit `99f6f02fecdb7dff40c3fbc9470f5907c29f74ca`.

This is the preferred deployment path. Start from a pristine DSH checkout/archive. Do **not** copy any previous `.ppl-e2e`, manual browser gates, `apps/web/tests/ppl-*`, or RC buildfix artifacts into the host.

## 1. Verify the pristine host

```bash
git rev-parse HEAD
git status --short
```

Expected commit is `99f6f02fecdb7dff40c3fbc9470f5907c29f74ca`; status must be empty.

## 2. Install only the Stable product integration

From DSH root:

```bash
export PPL_RELEASE=/d/Project/PPL/ppl-source-release-2026-08-19-stable-clean
node "$PPL_RELEASE/integrations/deepseek-harness-0.1.0-rc.7/install-clean-ppl-stable.mjs"
```

The installer rejects contaminated hosts and refuses unexpected host-source changes.

## 3. Link workspaces and verify runtime packages

```bash
pnpm install
node "$PPL_RELEASE/integrations/deepseek-harness-0.1.0-rc.7/verify-clean-ppl-stable.mjs"
```

## 4. Build normal product surfaces

```bash
pnpm run build:lib:host
pnpm run build:lib:client
pnpm --filter @deepseek-ai/dsh-web-frontend run build
```

No PPL synthetic test file is installed under `apps/web/tests`.

## 5. Normal operation

Inspect existing PPL snapshot sessions without enabling the live adapter:

```bash
pnpm dsh web
```

Create new PPL snapshots through the Runtime/DSH adapter:

```bash
PPL_LIVE=1 pnpm dsh web
```

On Git Bash, the environment prefix above is valid. Persona Inspector remains read-only and does not contribute prompt content.
