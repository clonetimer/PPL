# Start here — pristine DeepSeek Harness + PPL Stable

Do not reuse the previously modified Harness directory.

1. Extract a pristine DeepSeek Harness `0.1.0-rc.7` checkout/archive into a new directory.
2. Confirm `git rev-parse HEAD` is `99f6f02fecdb7dff40c3fbc9470f5907c29f74ca` and `git status --short` is empty.
3. From that pristine Harness root, run the clean PPL installer from this kit.

```bash
export PPL_RELEASE=/d/Project/PPL/ppl-stable-clean-dsh-kit-2026-08-19
node "$PPL_RELEASE/integrations/deepseek-harness-0.1.0-rc.7/install-clean-ppl-stable.mjs"
pnpm install
node "$PPL_RELEASE/integrations/deepseek-harness-0.1.0-rc.7/verify-clean-ppl-stable.mjs"
pnpm run build:lib:host
pnpm run build:lib:client
pnpm --filter @deepseek-ai/dsh-web-frontend run build
```

Normal APP inspection only:

```bash
pnpm dsh web
```

Enable live PPL Runtime/Adapter for new Persona snapshots:

```bash
PPL_LIVE=1 pnpm dsh web
```

The clean installer refuses a dirty or previously PPL-modified host. It never writes PPL files into `apps/web/tests`.
