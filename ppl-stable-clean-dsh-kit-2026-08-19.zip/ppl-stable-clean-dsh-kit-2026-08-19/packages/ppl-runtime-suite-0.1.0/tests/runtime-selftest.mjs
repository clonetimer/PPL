import { readFile } from 'node:fs/promises'
import { resolve as resolvePath } from 'node:path'
import assert from 'node:assert/strict'
import { PplDshBridge, DSH_DEFAULT_COMMIT_REASONS } from '../packages/adapter-dsh/lib/bridge.js'
import { PPL_PLUGIN_NAME } from '../packages/adapter-dsh/lib/dsh-projection.js'
import { assertJsonRoundTrip } from '../packages/runtime/lib/index.js'

const persona = JSON.parse(await readFile(resolvePath('packages/adapter-dsh/reference/zhuang_fangyi.pir.json'), 'utf8'))
const bridge = new PplDshBridge({ persona, scene: 'PRIVATE_NIGHT', profile: 'debug' })

function human(text) {
  return { role: 'user', content: [{ type: 'text', text }], source: { kind: 'user' } }
}
function tool(text = 'tool result') {
  return { role: 'user', content: [{ type: 'text', text }], source: { kind: 'tool', callId: 't1' } }
}
function snapshotEvent(seq, prepared) {
  return { seq, type: 'user/message', data: { source: { kind: 'plugin', plugin: PPL_PLUGIN_NAME, ppl: assertJsonRoundTrip(prepared.metadata) } } }
}
function turnEnd(seq, turn, reason) {
  return { seq, type: 'turn/end', data: { turn, reason: { kind: reason } } }
}

// Baseline oracle remains unchanged.
const events = []
const t1 = bridge.prepareStep({ events, sessionId: 'selftest', turn: 1, step: 1, messages: [human('方宜，我喜欢你。可以和我在一起吗？')] })
assert.equal(t1.resolution.resolved.relationships.admin.stage, 'trusted')
assert.equal(t1.resolution.pendingTransitions[0]?.to, 'lover')
events.push(snapshotEvent(1, t1), turnEnd(2, 1, 'completed'))
assert.equal(bridge.projectRuntime(events, 'selftest').relationships.admin.stage, 'lover')

const t2 = bridge.prepareStep({ events, sessionId: 'selftest', turn: 2, step: 1, messages: [human('今天辛苦了，过来靠一会儿吧。')] })
assert.deepEqual(t2.resolution.activeRules.map(r => r.id), ['ADMIN_COMFORT_TRUST', 'FATIGUE_DISCLOSURE', 'PRIVATE_THAW'])
assert.equal(t2.resolution.trace['traits.emotional_guard'].final, 0.32)
assert.equal(t2.resolution.pendingCommits[0]?.projected, 0.87)
events.push(snapshotEvent(3, t2), turnEnd(4, 2, 'completed'))
assert.equal(bridge.projectRuntime(events, 'selftest').relationships.admin.trust, 0.87)

const t3 = bridge.prepareStep({ events, sessionId: 'selftest', turn: 3, step: 1, messages: [human('别撑着了，再靠一会儿。')] })
assert.equal(t3.resolution.pendingCommits[0]?.projected, 0.88)
events.push(snapshotEvent(5, t3), turnEnd(6, 3, 'aborted'))
assert.equal(bridge.projectRuntime(events, 'selftest').relationships.admin.trust, 0.87)

// Runtime 0.1 Stable: a direct human steer at step>1 is a Persona event. Earlier snapshots in
// the same open turn are visible speculatively, but are committed only once the
// host turn reaches a committing terminal reason.
const steeringBridge = new PplDshBridge({ persona, scene: 'PRIVATE_NIGHT', profile: 'debug' })
const steeringEvents = []
const s1 = steeringBridge.prepareStep({
  events: steeringEvents,
  sessionId: 'steering-selftest',
  turn: 1,
  step: 1,
  messages: [human('方宜，我喜欢你。可以和我在一起吗？')],
})
steeringEvents.push(snapshotEvent(10, s1))

assert.equal(steeringBridge.projectRuntime(steeringEvents, 'steering-selftest').relationships, undefined)
const s2 = steeringBridge.prepareStep({
  events: steeringEvents,
  sessionId: 'steering-selftest',
  turn: 1,
  step: 2,
  messages: [human('还有一句，今天辛苦了，靠一会儿吧。')],
})
assert.equal(s2.runtimeBefore.relationships.admin.stage, 'lover')
assert.ok(s2.resolution.activeRules.some(rule => rule.id === 'PRIVATE_THAW'))
assert.equal(s2.resolution.pendingCommits[0]?.projected, 0.87)
steeringEvents.push(snapshotEvent(11, s2))

// Tool-only continuation never produces a PPL snapshot.
assert.equal(steeringBridge.prepareStep({
  events: steeringEvents,
  sessionId: 'steering-selftest',
  turn: 1,
  step: 3,
  messages: [tool()],
}), undefined)

// DSH max-tokens is success-like for PPL state: the durable human input and
// assistant output exist, so both staged Persona resolutions commit in order.
steeringEvents.push(turnEnd(12, 1, 'max-tokens'))
const afterMaxTokens = steeringBridge.projectRuntime(steeringEvents, 'steering-selftest')
assert.equal(afterMaxTokens.relationships.admin.stage, 'lover')
assert.equal(afterMaxTokens.relationships.admin.trust, 0.87)
assert.equal(afterMaxTokens.session.turn, 1)

// Duplicate snapshots for one host (turn, step) are a corruption signal.
const duplicateEvents = [snapshotEvent(20, s1), snapshotEvent(21, s1)]
assert.throws(
  () => steeringBridge.projectStagedRuntime(duplicateEvents, 'duplicate-selftest'),
  /more than one persona snapshot recorded for host turn 1 step 1/,
)

assert.deepEqual([...DSH_DEFAULT_COMMIT_REASONS], ['completed', 'max-tokens'])

const report = {
  schema: 'ppl.runtime/selftest-report/0.1',
  certRevision: '0.1.0-stable',
  passed: true,
  stageAfterConfession: 'lover',
  emotionalGuardComfort: 0.32,
  trustAfterCompletedComfort: 0.87,
  trustAfterAbortedComfort: 0.87,
  step2HumanSteeringResolved: true,
  stagedTransitionVisibleAtStep2: s2.runtimeBefore.relationships.admin.stage,
  maxTokensCommitsByDefaultOnDsh: true,
  trustAfterMaxTokensSteeringTurn: afterMaxTokens.relationships.admin.trust,
  duplicateTurnStepSnapshotRejected: true,
  hostSnapshotSchema: t2.metadata.schema,
}
console.log(JSON.stringify(report, null, 2))
