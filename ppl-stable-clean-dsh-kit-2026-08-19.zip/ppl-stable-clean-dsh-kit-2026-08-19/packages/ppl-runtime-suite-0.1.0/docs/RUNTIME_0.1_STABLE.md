# PPL Runtime 0.1.0 Stable

`@ppl/runtime` 0.1.0 and `@ppl/adapter-dsh` 0.1.0 are the stable promotion of the RC1 implementation. No Runtime or Adapter semantics changed during promotion.

Stable semantics:

- Host-neutral Runtime supports ordered `(turn, step)` snapshots inside one host Turn.
- Resolve remains separate from mutation; same-Turn snapshots are staged until terminal commit.
- A committing terminal applies all staged snapshots in step order; a rollback terminal discards all.
- DeepSeek Harness host policy commits on `completed` and `max-tokens`.
- Direct human steering at `step > 1` is a Persona event; tool-only continuation is not.
- Snapshot ABI remains `ppl.host-snapshot/0.1`; Resolution ABI remains `ppl.host-resolution/0.1`.

Promotion evidence is recorded in the top-level `PROMOTION_DECISION_0.1.0.md` and `validation/stable/`.
