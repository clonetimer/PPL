import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve, relative, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

const EXPECTED_HEAD = '99f6f02fecdb7dff40c3fbc9470f5907c29f74ca'
const here = dirname(fileURLToPath(import.meta.url))
const root = process.cwd()

function fail(message) {
  throw new Error(`[ppl-stable-clean-install] ${message}`)
}
function git(...args) {
  return execFileSync('git', args, { cwd: root, encoding: 'utf8' }).replace(/[\r\n]+$/, '')
}
function runNode(script) {
  return execFileSync(process.execPath, [script], { cwd: root, encoding: 'utf8' }).trim()
}
function norm(p) { return p.split(sep).join('/') }

const required = [
  'package.json',
  'packages/bundle/web-app/package.json',
  'packages/bundle/web-app/cordis.patch.yml',
  'tsconfig.client.json',
]
for (const p of required) if (!existsSync(resolve(root, p))) fail(`not a DeepSeek Harness root: missing ${p}`)

const head = git('rev-parse', 'HEAD')
if (head !== EXPECTED_HEAD) fail(`expected clean reference host ${EXPECTED_HEAD}, got ${head}`)
const branch = git('branch', '--show-current') || '(detached)'
const beforeStatus = git('status', '--porcelain=v1', '--untracked-files=all')
if (beforeStatus) fail(`worktree is not clean before PPL install:\n${beforeStatus}`)

const forbiddenBefore = [
  'packages/ppl',
  'packages/client/ui-ppl-inspector',
  'apps/web/tests/ppl-persona-inspector.e2e.ts',
  'apps/web/tests/ppl-persona-inspector.manual-gate.e2e.ts',
]
for (const p of forbiddenBefore) if (existsSync(resolve(root, p))) fail(`PPL contamination already exists before install: ${p}`)

const scripts = {
  runtime: resolve(here, 'runtime/install-runtime-payload.mjs'),
  live: resolve(here, 'runtime/install-live-data-gate.mjs'),
  app: resolve(here, 'app/install-persona-inspector.mjs'),
  verifyLive: resolve(here, 'runtime/verify-live-data-gate.mjs'),
  verifyApp: resolve(here, 'app/verify-install.mjs'),
}
for (const [name, p] of Object.entries(scripts)) if (!existsSync(p)) fail(`release missing ${name} script: ${p}`)

const outputs = {
  runtime: runNode(scripts.runtime),
  live: runNode(scripts.live),
  app: runNode(scripts.app),
  verifyLive: runNode(scripts.verifyLive),
  verifyApp: runNode(scripts.verifyApp),
}

for (const forbidden of [
  'apps/web/tests/ppl-persona-inspector.e2e.ts',
  'apps/web/tests/ppl-persona-inspector.manual-gate.e2e.ts',
  'scripts/ppl-manual-browser-gate.mts',
  'scripts/ppl-runtime-rc1-dsh-e2e.mts',
]) {
  if (existsSync(resolve(root, forbidden))) fail(`historical certification artifact leaked into clean host: ${forbidden}`)
}

const status = git('status', '--porcelain=v1', '--untracked-files=all')
const lines = status ? status.split(/\r?\n/).filter(Boolean) : []
const allowedExact = new Set([
  'packages/bundle/web-app/package.json',
  'packages/bundle/web-app/cordis.patch.yml',
  'tsconfig.client.json',
])
const allowedPrefixes = [
  'packages/ppl/runtime/',
  'packages/ppl/adapter-dsh/',
  'packages/client/ui-ppl-inspector/',
]
const unexpected = []
const changedPaths = []
for (const line of lines) {
  const raw = line.slice(3).trim()
  const pathPart = raw.includes(' -> ') ? raw.split(' -> ').at(-1) : raw
  const p = norm(pathPart.replace(/^"|"$/g, ''))
  changedPaths.push(p)
  if (!allowedExact.has(p) && !allowedPrefixes.some(prefix => p.startsWith(prefix))) unexpected.push({ line, path: p })
}
if (unexpected.length) fail(`unexpected host modifications after install:\n${unexpected.map(x => x.line).join('\n')}`)

const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))
const report = {
  schema: 'ppl.stable/clean-host-install/0.1',
  passed: true,
  referenceHost: {
    version: pkg.version,
    commit: head,
    branch,
  },
  ppl: {
    core: '0.3.0',
    runtime: '0.1.0',
    adapterDsh: '0.1.0',
    personaInspector: '0.1.0',
  },
  noHistoricalCertificationArtifacts: true,
  changedPaths,
  next: [
    'pnpm install',
    'node <PPL_RELEASE>/integrations/deepseek-harness-0.1.0-rc.7/verify-clean-ppl-stable.mjs',
    'pnpm run build:lib:host',
    'pnpm run build:lib:client',
    'pnpm --filter @deepseek-ai/dsh-web-frontend run build',
    'pnpm dsh web',
  ],
  installerOutputs: outputs,
}
writeFileSync(resolve(root, 'ppl-stable-clean-install-report.json'), JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report, null, 2))
