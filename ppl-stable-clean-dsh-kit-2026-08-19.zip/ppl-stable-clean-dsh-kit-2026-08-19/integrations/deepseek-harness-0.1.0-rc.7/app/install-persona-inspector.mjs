import { cp, mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const harnessRoot = process.cwd()
const payload = resolve(here, 'payload/packages/client/ui-ppl-inspector')
const target = resolve(harnessRoot, 'packages/client/ui-ppl-inspector')

async function patchFile(path, apply) {
  const before = await readFile(path, 'utf8')
  const after = apply(before)
  if (after === before) return false
  await writeFile(path, after)
  return true
}

function insertAfter(text, needle, addition, label) {
  if (text.includes(addition.trim())) return text
  const index = text.indexOf(needle)
  if (index < 0) throw new Error(`PPL APP installer: cannot find ${label}`)
  return text.slice(0, index + needle.length) + addition + text.slice(index + needle.length)
}

await mkdir(dirname(target), { recursive: true })
await cp(payload, target, { recursive: true, force: true })

const changes = []

if (await patchFile(resolve(harnessRoot, 'packages/bundle/web-app/package.json'), text =>
  insertAfter(
    text,
    '    "@deepseek-ai/dsh-client-ui-trajectory": "workspace:^",',
    '\n    "@ppl/app-dsh-persona-inspector": "workspace:^",',
    'web-app ui-trajectory dependency',
  ))) changes.push('packages/bundle/web-app/package.json')

if (await patchFile(resolve(harnessRoot, 'packages/bundle/web-app/cordis.patch.yml'), text =>
  insertAfter(
    text,
    "    - id: ui-trajectory\n      name: '@deepseek-ai/dsh-client-ui-trajectory'",
    "\n\n    # PPL APP 0.1: read-only Persona Inspector over durable source.ppl snapshots.\n    - id: ui-ppl-inspector\n      name: '@ppl/app-dsh-persona-inspector'",
    'web-app ui-trajectory cordis row',
  ))) changes.push('packages/bundle/web-app/cordis.patch.yml')

if (await patchFile(resolve(harnessRoot, 'tsconfig.client.json'), text =>
  insertAfter(
    text,
    '    { "path": "./packages/client/ui-trajectory" },',
    '\n    { "path": "./packages/client/ui-ppl-inspector" },',
    'client aggregate ui-trajectory reference',
  ))) changes.push('tsconfig.client.json')

console.log(JSON.stringify({
  schema: 'ppl.app/install-report/0.1',
  passed: true,
  harnessRoot,
  package: '@ppl/app-dsh-persona-inspector',
  target,
  patched: changes,
}, null, 2))
