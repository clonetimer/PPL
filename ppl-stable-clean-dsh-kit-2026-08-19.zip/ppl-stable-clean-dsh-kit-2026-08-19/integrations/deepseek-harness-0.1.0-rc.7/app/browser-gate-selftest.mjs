import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const root = process.cwd()
function assert(condition, message) {
  if (!condition) throw new Error(`ASSERTION FAILED: ${message}`)
}

const pkgPath = resolve(root, 'packages/client/ui-ppl-inspector/package.json')
const bundlePkgPath = resolve(root, 'packages/bundle/web-app/package.json')
const patchPath = resolve(root, 'packages/bundle/web-app/cordis.patch.yml')
const clientBundle = resolve(root, 'packages/client/ui-ppl-inspector/lib/client.js')
const frontendDist = resolve(root, 'apps/web/dist')

const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'))
const webPkg = JSON.parse(readFileSync(bundlePkgPath, 'utf8'))
const patch = readFileSync(patchPath, 'utf8')

const report = {
  schema: 'ppl.app/browser-gate-selftest/0.1',
  passed: true,
  checks: {
    versionStable: pkg?.version === '0.1.0',
    clientManifest: pkg?.dsh?.client?.platform === 'web',
    workspaceDependency: webPkg?.dependencies?.['@ppl/app-dsh-persona-inspector'] === 'workspace:^',
    cordisRoster: patch.includes("name: '@ppl/app-dsh-persona-inspector'"),
    builtClientBundle: existsSync(clientBundle),
    frontendDistPresent: existsSync(frontendDist),
  },
}

for (const [name, passed] of Object.entries(report.checks)) assert(passed, name)
console.log(JSON.stringify(report, null, 2))
