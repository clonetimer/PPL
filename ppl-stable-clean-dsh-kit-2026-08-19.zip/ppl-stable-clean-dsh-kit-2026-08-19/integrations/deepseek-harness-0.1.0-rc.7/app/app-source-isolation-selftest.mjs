import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const contractsPath = path.join(root, 'packages/client/ui-ppl-inspector/src/client/contracts.ts')
const viewPath = path.join(root, 'packages/client/ui-ppl-inspector/src/client/PersonaInspectorView.tsx')
const indexPath = path.join(root, 'packages/client/ui-ppl-inspector/src/client/index.ts')
const trajectoryTestPath = path.join(root, 'packages/client/ui-trajectory/tests/views.client.spec.tsx')

const contracts = fs.readFileSync(contractsPath, 'utf8')
const view = fs.readFileSync(viewPath, 'utf8')
const index = fs.readFileSync(indexPath, 'utf8')
const trajectoryTest = fs.readFileSync(trajectoryTestPath, 'utf8')

const checks = {
  noGlobalSnapshotMapAugmentation: !contracts.includes('interface ConversationViewSnapshotMap'),
  localAccessorExists: contracts.includes('function getPplInspectorSnapshot'),
  viewUsesLocalAccessor: view.includes('getPplInspectorSnapshot(snapshot.views)'),
  loaderUsesLocalAccessor: index.includes('getPplInspectorSnapshot(session.getSnapshot().views)'),
  hostTrajectoryTestUntouched: trajectoryTest.includes("target === 'trajectory' ? trajectory : undefined"),
}
const passed = Object.values(checks).every(Boolean)
console.log(JSON.stringify({ schema: 'ppl.app/fix4-selftest/0.1', passed, checks }, null, 2))
if (!passed) process.exitCode = 1
