import { access, readFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const root = process.cwd()
const expected = [
  'packages/client/ui-ppl-inspector/package.json',
  'packages/client/ui-ppl-inspector/src/client/index.ts',
  'packages/client/ui-ppl-inspector/src/client/PersonaInspectorView.tsx',
  'packages/client/ui-ppl-inspector/src/client/definition.ts',
]
for (const path of expected) await access(resolve(root, path))
const appPkg = JSON.parse(await readFile(resolve(root, 'packages/client/ui-ppl-inspector/package.json'), 'utf8'))
const definition = await readFile(resolve(root, 'packages/client/ui-ppl-inspector/src/client/definition.ts'), 'utf8')
const viewModel = await readFile(resolve(root, 'packages/client/ui-ppl-inspector/src/client/view-model.ts'), 'utf8')
const bundlePkg = await readFile(resolve(root, 'packages/bundle/web-app/package.json'), 'utf8')
const cordis = await readFile(resolve(root, 'packages/bundle/web-app/cordis.patch.yml'), 'utf8')
const tsconfig = await readFile(resolve(root, 'tsconfig.client.json'), 'utf8')
const checks = {
  packageCopied: true,
  versionStable: appPkg.version === '0.1.0',
  multiSnapshotDefinition: definition.includes('pplSnapshotDefinition') && definition.includes('pplTurnEndDefinition'),
  maxTokensAppliedStatus: viewModel.includes("new Set(['completed', 'max-tokens'])"),
  bundleDependency: bundlePkg.includes('"@ppl/app-dsh-persona-inspector": "workspace:^"'),
  cordisEntry: cordis.includes("name: '@ppl/app-dsh-persona-inspector'"),
  clientReference: tsconfig.includes('./packages/client/ui-ppl-inspector'),
}
const passed = Object.values(checks).every(Boolean)
console.log(JSON.stringify({ schema: 'ppl.app/install-verification/0.1', certRevision: 'stable', passed, root, checks }, null, 2))
if (!passed) process.exitCode = 1
