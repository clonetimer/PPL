# DeepSeek Harness integration — PPL 0.1.0 Stable

Reference host: DeepSeek Harness `0.1.0-rc.7`, commit `99f6f02fecdb7dff40c3fbc9470f5907c29f74ca`.

## Install Runtime + Adapter

From the DSH repository root:

```bash
node <release>/integrations/deepseek-harness-0.1.0-rc.7/runtime/install-runtime-payload.mjs
pnpm install
pnpm run build:lib:host
node <release>/integrations/deepseek-harness-0.1.0-rc.7/runtime/runtime-package-selftest.mjs
```

## Optional live PPL projection

Install the opt-in composition row:

```bash
node <release>/integrations/deepseek-harness-0.1.0-rc.7/runtime/install-live-data-gate.mjs
node <release>/integrations/deepseek-harness-0.1.0-rc.7/runtime/verify-live-data-gate.mjs
```

The Adapter stays disabled unless the product is booted with:

```bash
PPL_LIVE=1 pnpm dsh web
```

Without `PPL_LIVE=1`, historical PPL sessions remain viewable but no new Runtime Persona projection is injected.

## Install Persona Inspector

```bash
node <release>/integrations/deepseek-harness-0.1.0-rc.7/app/install-persona-inspector.mjs
pnpm install
node <release>/integrations/deepseek-harness-0.1.0-rc.7/app/verify-install.mjs
pnpm run build:lib:client
pnpm --filter @deepseek-ai/dsh-web-frontend run build
node <release>/integrations/deepseek-harness-0.1.0-rc.7/app/browser-gate-selftest.mjs
```

Then boot the ordinary product:

```bash
pnpm dsh web
```

Persona Inspector is read-only and contributes no prompt content. Prompt projection belongs to `@ppl/adapter-dsh`, not the APP.

Historical RC1 synthetic certification experiments are retained under `certification/historical-rc1/`; they are not normal runtime prerequisites.
