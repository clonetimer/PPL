import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

const root = process.cwd()
const EXPECTED_HEAD = '99f6f02fecdb7dff40c3fbc9470f5907c29f74ca'
function fail(message) { throw new Error(`[ppl-stable-clean-verify] ${message}`) }
function runNode(script) {
  return execFileSync(process.execPath, [script], { cwd: root, encoding: 'utf8' }).trim()
}
const commit = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim()
if (commit !== EXPECTED_HEAD) fail(`reference host changed: ${commit}`)

for (const forbidden of [
  'apps/web/tests/ppl-persona-inspector.e2e.ts',
  'apps/web/tests/ppl-persona-inspector.manual-gate.e2e.ts',
  'scripts/ppl-manual-browser-gate.mts',
  'scripts/ppl-runtime-rc1-dsh-e2e.mts',
]) if (existsSync(resolve(root, forbidden))) fail(`historical certification artifact present: ${forbidden}`)

const runtimePkg = JSON.parse(readFileSync(resolve(root, 'packages/ppl/runtime/package.json'), 'utf8'))
const adapterPkg = JSON.parse(readFileSync(resolve(root, 'packages/ppl/adapter-dsh/package.json'), 'utf8'))
const appPkg = JSON.parse(readFileSync(resolve(root, 'packages/client/ui-ppl-inspector/package.json'), 'utf8'))
if (runtimePkg.version !== '0.1.0' || adapterPkg.version !== '0.1.0' || appPkg.version !== '0.1.0') {
  fail(`unexpected versions runtime=${runtimePkg.version} adapter=${adapterPkg.version} app=${appPkg.version}`)
}

const here = dirname(fileURLToPath(import.meta.url))
const runtimeSelftest = resolve(here, 'runtime/runtime-package-selftest.mjs')
const verifyLive = resolve(here, 'runtime/verify-live-data-gate.mjs')
const verifyApp = resolve(here, 'app/verify-install.mjs')
const outputs = {
  runtimeSelftest: runNode(runtimeSelftest),
  live: runNode(verifyLive),
  app: runNode(verifyApp),
}
const report = {
  schema: 'ppl.stable/clean-host-verification/0.1',
  passed: true,
  referenceHostCommit: commit,
  runtimeVersion: runtimePkg.version,
  adapterVersion: adapterPkg.version,
  appVersion: appPkg.version,
  noHistoricalCertificationArtifacts: true,
  outputs,
}
writeFileSync(resolve(root, 'ppl-stable-clean-verification.json'), JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report, null, 2))
