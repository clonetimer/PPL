/**
 * DeepSeek Harness workspace-build shield.
 *
 * This PPL payload is already-built ESM. DSH's generic host workspace build
 * otherwise assumes compiler staging entries under lib/types/*.js.
 *
 * DSH's own tsdown client preset documents a falsey `entry` as the contract
 * for removing a package from workspace entry resolution. No DSH build helper
 * is imported here so the portable package manifest gains no host build
 * dependency.
 */
export default { entry: '' }
