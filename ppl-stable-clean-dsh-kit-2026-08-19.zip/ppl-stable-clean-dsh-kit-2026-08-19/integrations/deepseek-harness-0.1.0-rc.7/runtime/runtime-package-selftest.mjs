import { readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const runtimePkg = JSON.parse(readFileSync(resolve('packages/ppl/runtime/package.json'), 'utf8'))
const adapterPkg = JSON.parse(readFileSync(resolve('packages/ppl/adapter-dsh/package.json'), 'utf8'))
if (runtimePkg.version !== '0.1.0') throw new Error(`expected @ppl/runtime 0.1.0, got ${runtimePkg.version}`)
if (adapterPkg.version !== '0.1.0') throw new Error(`expected @ppl/adapter-dsh 0.1.0, got ${adapterPkg.version}`)

const { PplDshBridge, DSH_DEFAULT_COMMIT_REASONS } = await import(
  pathToFileURL(resolve('packages/ppl/adapter-dsh/lib/bridge.js')).href
)
const persona = JSON.parse(readFileSync(resolve('packages/ppl/adapter-dsh/reference/zhuang_fangyi.pir.json'), 'utf8'))
const bridge = new PplDshBridge({ persona, scene: 'PRIVATE_NIGHT', profile: 'standard' })
const human = text => ({ source: { kind: 'user' }, content: [{ type: 'text', text }] })
const confession = bridge.prepareStep({
  events: [], sessionId: 'live-selftest', turn: 1, step: 1,
  messages: [human('方宜，我喜欢你。可以和我在一起吗？')],
})
if (!confession?.resolution?.pendingTransitions?.some(x => x.to === 'lover')) throw new Error('confession transition missing')
if (JSON.stringify([...DSH_DEFAULT_COMMIT_REASONS]) !== JSON.stringify(['completed', 'max-tokens'])) {
  throw new Error(`unexpected DSH commit reasons: ${JSON.stringify([...DSH_DEFAULT_COMMIT_REASONS])}`)
}

const report = {
  schema: 'ppl.live/runtime-package-selftest/0.1',
  certRevision: 'stable-steering-terminal-policy',
  harnessRevision: 'buildfix2-evidence-output',
  passed: true,
  runtimeVersion: runtimePkg.version,
  adapterVersion: adapterPkg.version,
  eventType: confession.event.type,
  pendingTransition: confession.resolution.pendingTransitions[0],
  dshDefaultCommitReasons: [...DSH_DEFAULT_COMMIT_REASONS],
}
const output = resolve(process.env.PPL_SELFTEST_OUTPUT ?? 'ppl-runtime-stable-package-selftest.json')
writeFileSync(output, `${JSON.stringify(report, null, 2)}\n`, 'utf8')
console.log(JSON.stringify({ ...report, evidenceFile: output }, null, 2))
