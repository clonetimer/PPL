import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { resolve } from 'node:path'

const root = process.cwd()
const webPkgPath = resolve(root, 'packages/bundle/web-app/package.json')
const cordisPath = resolve(root, 'packages/bundle/web-app/cordis.patch.yml')
const runtimePkg = resolve(root, 'packages/ppl/runtime/package.json')
const adapterPkg = resolve(root, 'packages/ppl/adapter-dsh/package.json')

function fail(message) { throw new Error(`[ppl-live-install] ${message}`) }
for (const p of [webPkgPath, cordisPath]) if (!existsSync(p)) fail(`run from DeepSeek Harness repo root; missing ${p}`)
for (const p of [runtimePkg, adapterPkg]) if (!existsSync(p)) fail(`drop-in package missing ${p}`)

const webPkg = JSON.parse(readFileSync(webPkgPath, 'utf8'))
webPkg.dependencies ??= {}
webPkg.dependencies['@ppl/adapter-dsh'] = 'workspace:*'
writeFileSync(webPkgPath, JSON.stringify(webPkg, null, 2) + '\n')

let cordis = readFileSync(cordisPath, 'utf8')
if (!cordis.includes("name: '@ppl/adapter-dsh'")) {
  const anchor = `    - id: session-stats\n      name: '@deepseek-ai/dsh-session-stats'\n`
  if (!cordis.includes(anchor)) fail('web-app cordis anchor session-stats not found; Harness layout changed')
  const row = `${anchor}\n    # PPL Live Data Gate (opt-in): host-neutral PPL Runtime projected through\n    # the DeepSeek adapter. It observes all agent lifecycle events and injects\n    # static/dynamic persona sections without modifying agent preset files.\n    - id: ppl-runtime\n      name: '@ppl/adapter-dsh'\n      disabled: !!js process.env.PPL_LIVE !== '1'\n      config:\n        scene: !!js process.env.PPL_SCENE ?? 'PRIVATE_NIGHT'\n        profile: !!js process.env.PPL_PROFILE ?? 'standard'\n`
  cordis = cordis.replace(anchor, row)
  writeFileSync(cordisPath, cordis)
}

console.log(JSON.stringify({
  schema: 'ppl.live/install-report/0.1',
  passed: true,
  package: '@ppl/adapter-dsh',
  runtime: '@ppl/runtime',
  webDependency: webPkg.dependencies['@ppl/adapter-dsh'],
  optInEnv: 'PPL_LIVE=1',
  defaultScene: 'PRIVATE_NIGHT',
}, null, 2))
