import { cp, mkdir, readFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const root = process.cwd()
const payload = resolve(here, 'payload/packages/ppl')
const target = resolve(root, 'packages/ppl')

await mkdir(target, { recursive: true })
await cp(payload, target, { recursive: true, force: true })

const shieldPackages = ['runtime', 'adapter-dsh']
const shield = {}
for (const packageName of shieldPackages) {
  const configPath = resolve(target, packageName, 'tsdown.config.ts')
  const source = await readFile(configPath, 'utf8')
  if (!/entry\s*:\s*['"]{2}/.test(source)) {
    throw new Error(`PPL DSH workspace build shield missing falsey entry: ${configPath}`)
  }
  shield[packageName] = {
    config: configPath,
    skipWorkspaceBuild: true,
  }
}

console.log(JSON.stringify({
  schema: 'ppl.source-release/dsh-runtime-payload-install/0.2',
  passed: true,
  target,
  workspaceBuildShield: shield,
}, null, 2))
