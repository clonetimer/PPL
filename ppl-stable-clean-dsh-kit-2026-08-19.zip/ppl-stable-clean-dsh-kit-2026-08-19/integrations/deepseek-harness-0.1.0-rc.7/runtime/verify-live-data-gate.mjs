import { readFileSync, existsSync } from 'node:fs'
import { resolve } from 'node:path'

const root = process.cwd()
const files = {
  runtime: resolve(root, 'packages/ppl/runtime/lib/index.js'),
  runtimePkg: resolve(root, 'packages/ppl/runtime/package.json'),
  projection: resolve(root, 'packages/ppl/runtime/lib/projection.js'),
  adapter: resolve(root, 'packages/ppl/adapter-dsh/lib/index.js'),
  adapterPkg: resolve(root, 'packages/ppl/adapter-dsh/package.json'),
  bridge: resolve(root, 'packages/ppl/adapter-dsh/lib/bridge.js'),
  persona: resolve(root, 'packages/ppl/adapter-dsh/reference/zhuang_fangyi.pir.json'),
  webPkg: resolve(root, 'packages/bundle/web-app/package.json'),
  cordis: resolve(root, 'packages/bundle/web-app/cordis.patch.yml'),
}
const runtimePkg = JSON.parse(readFileSync(files.runtimePkg, 'utf8'))
const adapterPkg = JSON.parse(readFileSync(files.adapterPkg, 'utf8'))
const projection = readFileSync(files.projection, 'utf8')
const bridge = readFileSync(files.bridge, 'utf8')
const webPkg = JSON.parse(readFileSync(files.webPkg, 'utf8'))
const cordis = readFileSync(files.cordis, 'utf8')
const checks = {
  runtimePackage: existsSync(files.runtime),
  runtimeVersionStable: runtimePkg.version === '0.1.0',
  adapterPackage: existsSync(files.adapter),
  adapterVersionStable: adapterPkg.version === '0.1.0',
  referencePersona: existsSync(files.persona),
  multiSnapshotProjection: projection.includes('includePending') && projection.includes('more than one persona snapshot recorded'),
  dshMaxTokensPolicy: bridge.includes("['completed', 'max-tokens']"),
  stepGreaterThanOneSupport: bridge.includes('projectStagedRuntime') && !bridge.includes('if (input.step !== 1)'),
  webDependency: webPkg.dependencies?.['@ppl/adapter-dsh'] === 'workspace:*',
  webRow: cordis.includes("name: '@ppl/adapter-dsh'"),
  optIn: cordis.includes("process.env.PPL_LIVE !== '1'"),
  privateSceneDefault: cordis.includes("process.env.PPL_SCENE ?? 'PRIVATE_NIGHT'"),
}
const passed = Object.values(checks).every(Boolean)
console.log(JSON.stringify({ schema: 'ppl.live/verification/0.1', certRevision: 'stable', passed, checks }, null, 2))
if (!passed) process.exitCode = 1
