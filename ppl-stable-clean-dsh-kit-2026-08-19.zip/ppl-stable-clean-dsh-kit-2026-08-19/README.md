# PPL Source Release — 2026-08-19 · 0.1.0 Stable

This is the current stable PPL baseline. Do not combine it with earlier RC1 Buildfix/certification folders.

## Preferred deployment: pristine DSH only

Use `CLEAN_DSH_DEPLOY.md`. The clean installer refuses a dirty/previously-PPL-modified Harness and never writes certification files into `apps/web/tests`.

## Stable components

- PPL Core: **0.3.0 Stable** (frozen)
- `@ppl/runtime`: **0.1.0 Stable**
- `@ppl/adapter-dsh`: **0.1.0 Stable**
- Persona Inspector (`@ppl/app-dsh-persona-inspector`): **0.1.0 Stable**
- Host Snapshot ABI: `ppl.host-snapshot/0.1`
- Host Resolution ABI: `ppl.host-resolution/0.1`
- Reference host: DeepSeek Harness `0.1.0-rc.7`, commit `99f6f02fecdb7dff40c3fbc9470f5907c29f74ca`

## Normal DSH use — restored known-good path

Persona Inspector is a **read-only historical/live snapshot viewer**. It does not contribute prompt content.

From the DeepSeek Harness root:

```bash
node <PPL_RELEASE>/integrations/deepseek-harness-0.1.0-rc.7/runtime/install-runtime-payload.mjs
node <PPL_RELEASE>/integrations/deepseek-harness-0.1.0-rc.7/runtime/install-live-data-gate.mjs
node <PPL_RELEASE>/integrations/deepseek-harness-0.1.0-rc.7/app/install-persona-inspector.mjs
pnpm install
pnpm run build:lib:host
pnpm run build:lib:client
pnpm --filter @deepseek-ai/dsh-web-frontend run build
```

To inspect **existing persisted PPL sessions only**, boot normally:

```bash
pnpm dsh web
```

To create **new live PPL snapshots**, opt in to the Runtime Adapter:

```bash
PPL_LIVE=1 pnpm dsh web
```

The Adapter (not the APP) owns PPL prompt projection. It registers the static Persona section in DSH system prompt order and injects a dynamic PPL snapshot before a model step.

## Promotion evidence

See `PROMOTION_DECISION_0.1.0.md`, `KNOWN_GOOD_BASELINE_AUDIT.md`, and `validation/stable/`.

The synthetic RC1 Web E2E/manual-browser scaffold is retained only as historical test-infrastructure work under `certification/historical-rc1/`; it is **not** required to run PPL or Persona Inspector.
