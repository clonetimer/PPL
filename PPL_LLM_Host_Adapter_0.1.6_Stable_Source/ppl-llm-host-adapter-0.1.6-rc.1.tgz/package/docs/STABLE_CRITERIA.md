# PPL LLM Host Adapter 0.1 Stable Acceptance

All required provider-neutral criteria passed at promotion:

- legacy authority boundary regression;
- retry / timeout / abort lifecycle;
- 429 retry budget;
- streaming partials never mutate Profile state;
- Session Lease rejects stale concurrent same-session transactions;
- Tool allowlist and argument schema;
- Tool provenance digest;
- tool idempotency in-process and across restart using JSON store;
- Agent/Judge independence required/preferred enforcement;
- blocked draft cannot mutate durable state;
- policy-preserving retry commits exactly once;
- Restricted Tutor Observer gate;
- HostSource provenance lock and Research Evidence Judge gate;
- OpenAI Responses provider local HTTP/SSE protocol conformance;
- current GPT-5.6 Sol Tutor and Research live semantic gate;
- npm tarball isolated install/import;
- final Source ZIP offline reinstall and full regression;
- no node_modules shipped.

Not claimed by this Stable decision:

- live OpenAI API transport certification;
- live Anthropic/DeepSeek/local-model provider certification;
- two genuinely independent LLMs exercised in one live run;
- provider rate/latency SLO certification.
