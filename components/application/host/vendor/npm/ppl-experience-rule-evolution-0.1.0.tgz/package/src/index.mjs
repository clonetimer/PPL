import crypto from 'node:crypto'

export const PPL_EXPERIENCE_RULE_SCHEMA = 'ppl.experience-rule/0.1'
export const PPL_EXPERIENCE_RULE_CAPSULE_SCHEMA = 'ppl.experience-rule-capsule/0.1'
export const EXPERIENCE_RULE_MODES = Object.freeze(['off', 'observe', 'evaluation', 'enforce'])
const STATUSES = new Set(['candidate', 'validated', 'retired'])
const PHASES = new Set(['pre-judge'])
const EFFECTS = new Set(['retry-with-host-owned-repair'])

function arr(value) { return Array.isArray(value) ? value : [] }
function uniqStrings(value) { return [...new Set(arr(value).map(x => String(x ?? '').trim()).filter(Boolean))] }
function clone(value) { return value === undefined ? undefined : JSON.parse(JSON.stringify(value)) }
function sha256(value) { return crypto.createHash('sha256').update(typeof value === 'string' ? value : JSON.stringify(value)).digest('hex') }

export function validateExperienceRule(rule) {
  const errors = []
  if (!rule || typeof rule !== 'object' || Array.isArray(rule)) return { valid: false, errors: ['rule must be object'] }
  if (rule.schema !== PPL_EXPERIENCE_RULE_SCHEMA) errors.push(`schema must be ${PPL_EXPERIENCE_RULE_SCHEMA}`)
  if (!/^rule_[a-z0-9_]+$/u.test(String(rule.ruleId || ''))) errors.push('ruleId invalid')
  if (!String(rule.version || '').trim()) errors.push('version required')
  if (!STATUSES.has(String(rule.status || ''))) errors.push('status invalid')
  if (!['tutor', 'research', 'life', 'shared'].includes(String(rule.domain || ''))) errors.push('domain invalid')
  if (!rule.activation || typeof rule.activation !== 'object') errors.push('activation required')
  if (String(rule.activation?.detector || '') !== 'host-deterministic-policy-code') errors.push('activation.detector must be host-deterministic-policy-code')
  const codes = uniqStrings(rule.activation?.policyCodes)
  if (!codes.length) errors.push('activation.policyCodes required')
  if (!rule.action || typeof rule.action !== 'object') errors.push('action required')
  if (!PHASES.has(String(rule.action?.phase || ''))) errors.push('action.phase invalid')
  if (!EFFECTS.has(String(rule.action?.effect || ''))) errors.push('action.effect invalid')
  if (rule.action?.skipJudgeOnMatchedDraft !== true) errors.push('action.skipJudgeOnMatchedDraft must be true')
  if (!rule.authority || rule.authority?.precedence !== 'below-host-policy') errors.push('authority.precedence must be below-host-policy')
  const forbidden = uniqStrings(rule.authority?.mustNotOverride)
  for (const required of ['response-contract', 'profile-policy', 'durable-state', 'judge-on-unknown-failures']) {
    if (!forbidden.includes(required)) errors.push(`authority.mustNotOverride missing ${required}`)
  }
  if (!rule.provenance || typeof rule.provenance !== 'object') errors.push('provenance required')
  if (!uniqStrings(rule.provenance?.evidenceSha256).length) errors.push('provenance.evidenceSha256 required')
  return { valid: errors.length === 0, errors }
}

export function normalizeExperienceRuleMode(mode = 'off') {
  const value = String(mode || 'off')
  if (!EXPERIENCE_RULE_MODES.includes(value)) throw new Error(`Unsupported experience rule mode: ${value}`)
  return value
}

export function prepareExperienceRules(rules = [], mode = 'off') {
  const normalizedMode = normalizeExperienceRuleMode(mode)
  const prepared = []
  for (const input of arr(rules)) {
    const check = validateExperienceRule(input)
    if (!check.valid) throw new Error(`Invalid experience rule: ${check.errors.join('; ')}`)
    const rule = clone(input)
    if (rule.status === 'retired') continue
    if (normalizedMode === 'enforce' && rule.status !== 'validated') throw new Error(`Enforce mode requires validated rule: ${rule.ruleId}`)
    prepared.push(rule)
  }
  return Object.freeze({ mode: normalizedMode, rules: Object.freeze(prepared) })
}

export function evaluatePreJudgeExperienceRules(preparedOrRules, judgeRequest, options = {}) {
  const prepared = preparedOrRules?.mode ? preparedOrRules : prepareExperienceRules(preparedOrRules, options.mode || 'off')
  const deterministic = arr(judgeRequest?.deterministicViolations)
  const role = String(judgeRequest?.modelRole || '')
  const matches = []
  for (const rule of prepared.rules) {
    if (rule.domain !== 'shared' && rule.domain !== role) continue
    const codes = new Set(uniqStrings(rule.activation?.policyCodes))
    const violations = deterministic.filter(v => codes.has(String(v?.code || '')))
    if (!violations.length) continue
    matches.push({
      ruleId: rule.ruleId,
      ruleVersion: rule.version,
      ruleStatus: rule.status,
      violations: clone(violations),
    })
  }
  const enforce = prepared.mode === 'evaluation' || prepared.mode === 'enforce'
  const violations = []
  const seen = new Set()
  if (enforce) {
    for (const match of matches) for (const violation of match.violations) {
      const key = `${violation.code}:${violation.evidenceQuote || ''}`
      if (seen.has(key)) continue
      seen.add(key)
      violations.push({ ...violation, experienceRuleIds: matches.filter(m => m.violations.some(v => v.code === violation.code)).map(m => m.ruleId) })
    }
  }
  return {
    mode: prepared.mode,
    matched: matches.length > 0,
    enforced: enforce && violations.length > 0,
    matches,
    violations,
    skipJudge: enforce && violations.some(v => String(v.severity || '') === 'error'),
  }
}

export function distillDeterministicFastPathCandidate(input = {}) {
  const total = Number(input.totalRecords || 0)
  const structurallyValid = Number(input.structurallyValidRecords ?? total)
  const targetMatches = Number(input.targetPolicyCodeMatches || 0)
  const code = String(input.policyCode || '').trim()
  const domain = String(input.domain || '').trim()
  const evidenceSha256 = uniqStrings(input.evidenceSha256)
  if (!total || !structurallyValid || !code || !domain || !evidenceSha256.length) throw new Error('insufficient distillation input')
  const coverage = targetMatches / structurallyValid
  const minCoverage = Number(input.minimumCoverage ?? 0.80)
  if (coverage < minCoverage) throw new Error(`target deterministic coverage ${coverage.toFixed(4)} below minimum ${minCoverage.toFixed(4)}`)
  const slug = code.toLowerCase().replace(/[^a-z0-9]+/gu, '_').replace(/^_|_$/gu, '')
  const rule = {
    schema: PPL_EXPERIENCE_RULE_SCHEMA,
    ruleId: `rule_${slug}_prejudge_fastpath`,
    version: String(input.version || '0.1.0-candidate.1'),
    status: 'candidate',
    domain,
    summary: String(input.summary || `Repeated real failures are already covered by Host deterministic policy code ${code}; retry locally before invoking the external Judge.`),
    activation: {
      detector: 'host-deterministic-policy-code',
      policyCodes: [code],
    },
    action: {
      phase: 'pre-judge',
      effect: 'retry-with-host-owned-repair',
      skipJudgeOnMatchedDraft: true,
      repairCompiler: 'compileRetryRequest',
    },
    authority: {
      precedence: 'below-host-policy',
      mustNotOverride: ['response-contract', 'profile-policy', 'durable-state', 'judge-on-unknown-failures'],
    },
    provenance: {
      sourceKind: 'real-execution-replay',
      evidenceSha256,
      totalRecords: total,
      structurallyValidRecords: structurallyValid,
      targetPolicyCodeMatches: targetMatches,
      deterministicCoverage: Number(coverage.toFixed(6)),
      distilledAt: input.distilledAt || new Date().toISOString(),
    },
  }
  const check = validateExperienceRule(rule)
  if (!check.valid) throw new Error(check.errors.join('; '))
  return rule
}

export function buildExperienceRuleCapsule(input = {}) {
  const ruleCheck = validateExperienceRule(input.rule)
  if (!ruleCheck.valid) throw new Error(`invalid rule: ${ruleCheck.errors.join('; ')}`)
  const replay = input.replay || {}
  if (replay.realEvidence !== true) throw new Error('capsule requires real evidence replay')
  if (!Number.isInteger(replay.totalRecords) || replay.totalRecords < 1) throw new Error('capsule replay.totalRecords required')
  if (!Array.isArray(replay.artifacts) || replay.artifacts.length < 1) throw new Error('capsule replay artifacts required')
  return {
    schema: PPL_EXPERIENCE_RULE_CAPSULE_SCHEMA,
    capsuleId: `capsule_${sha256({ rule: input.rule.ruleId, replay }).slice(0, 20)}`,
    rule: { ruleId: input.rule.ruleId, version: input.rule.version, status: input.rule.status },
    outcome: clone(input.outcome || {}),
    replay: clone(replay),
    createdAt: input.createdAt || new Date().toISOString(),
  }
}
