# Changelog

## 0.1.0 — 2026-08-26
- Promoted `0.1.0-rc.1` to Stable after real R3 qualification.
- Runtime source is unchanged from RC1.
- Stable promotion validates the lifecycle/runtime; specific rules remain separately provenance-bound assets and require `status=validated` for `enforce` mode.

## 0.1.0-rc.1
- Introduces provenance-bound Experience Rule schema.
- Adds candidate/validated/retired lifecycle.
- Adds off/observe/evaluation/enforce modes.
- Adds deterministic pre-Judge policy-code fast-path evaluation.
- Adds deterministic candidate distillation and Capsule construction.
