# PPL Experience Rule Evolution 0.1.0 Stable

This package repositions GEP-style experience from an advisory runtime prompt overlay into a deterministic **Experience Distillation / Rule Evolution** layer.

The package does not generate user answers. It turns repeated, provenance-bound execution failures into candidate protocol rules that can be replayed, reviewed, and later enforced by the Host without weakening Profile, durable-state, response-contract, or Judge authority.

## First supported compilation target

`host-deterministic-policy-code -> pre-judge Host-owned retry`

Known deterministic failures can therefore avoid an unnecessary external Judge call on the rejected draft. Unknown failures still go to the Judge.

Candidate rules may run only in explicit `evaluation` mode. `enforce` mode requires `status=validated`.


## Stable promotion

Promoted from `0.1.0-rc.1` after real R3 full-Application qualification. Runtime source is byte-identical to RC1. Production `enforce` mode still requires an explicitly supplied `status=validated` rule; the package does not silently enable rules.
